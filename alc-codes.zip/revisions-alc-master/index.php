<?php
$user = true;

if ($user) {
    header("location: login");
}
?>